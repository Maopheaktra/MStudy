
// 1-  Write something in the console
let object = {"name": "rady", "age": 26};
// TODO: console object and check it on the console in your web browser

// 2-  Write something in the HTML document
// TODO: Change h2 content to "I love JavaScript"

// 3-  Display an alert
// TODO: Display alert with message "Welcome to JavaScript World"