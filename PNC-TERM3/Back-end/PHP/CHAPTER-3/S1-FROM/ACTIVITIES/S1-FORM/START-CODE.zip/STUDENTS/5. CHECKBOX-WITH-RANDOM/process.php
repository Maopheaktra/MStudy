<?php require_once 'templates/header.php' ?>
<?php

$colors = ['primary', 'danger', 'info', 'warning', 'success', 'secondary', 'dark'];
// CODE HERE 
?>
    <div class="card">
        
        <div class="card-body">
            <?php
            // CODE HERE
            ?>
        </div>
    </div>


<?php require_once 'templates/footer.php' ?>