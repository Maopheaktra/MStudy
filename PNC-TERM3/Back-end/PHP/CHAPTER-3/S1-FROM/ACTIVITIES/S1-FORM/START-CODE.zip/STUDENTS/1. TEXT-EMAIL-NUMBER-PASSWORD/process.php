<?php // HEADER ?>
<ul class="list-group">
<?php
   // YOUR CODE HERE
?>
    <li class="list-group-item"><?php // name; ?></li>
    <li class="list-group-item"><?php // email; ?></li>
    <li class="list-group-item"><?php // password; ?></li>
    <li class="list-group-item"><?php // number; ?></li>
    <li class="list-group-item"><?php // message; ?></li>

</ul>
<?php // FOOTER ?>