<?php // HEADER ?>
<?php
    // YOUR CODE HERE 
?>
    <div class="alert alert-secondary">
        <strong>Color: </strong> <span><?php //color; ?></span>
    </div>
    <div class="alert alert-info">
        <strong>Range: </strong> <span><?php //range; ?></span>
    </div>
    <div class="alert alert-danger">
        <strong>Date: </strong> <span><?php //date; ?></span>
    </div>

<?php //FOOTER ?>