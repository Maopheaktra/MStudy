<?php require_once 'templates/header.php' ?>
<table class="table table-striped table-bordered">
    <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        <th>Number</th>
        <th>Message</th>
        <th>Provinces</th>
        <th>Gender</th>
        <th>Subject</th>
    </tr>
    <?php
  
    ?>
        <tr>
            <td><?php //name; ?></td>
            <td><?php //email; ?></td>
            <td><?php //password; ?></td>
            <td><?php //number; ?></td>
            <td><?php //message; ?></td>
            <td><?php //province; ?></td>
            <td>
                <?php 
                   // subjects
                ?>
            </td>
            <td><?php // gender ?></td>
        </tr>
 
</table>
<?php require_once 'templates/footer.php' ?>