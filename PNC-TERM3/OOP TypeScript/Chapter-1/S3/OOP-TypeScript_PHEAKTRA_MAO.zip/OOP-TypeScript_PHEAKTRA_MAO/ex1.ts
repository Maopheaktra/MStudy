// Instructions:
// • Hover over red squigglies to inspect the TS errors.
// • Hover over variables to inspect their types.
// • Fix the error on line 8 by changing the value of pi to the expected type.
let pi = 3.14159;
let tau = pi * 2;

console.log("[Exercise 1.1]", `${tau} is ${pi} times two.`);