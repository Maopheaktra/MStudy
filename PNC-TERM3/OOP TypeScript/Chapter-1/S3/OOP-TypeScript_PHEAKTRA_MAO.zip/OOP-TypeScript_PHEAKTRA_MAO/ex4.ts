// Instructions:
// • The array should contain ONLY numbers
// • Add types annotation and then fix errors on the code ( if any)

const value1 = 6;
const value2 = 12.03;
const values = [value1, value2];

// Print the sum of the 2 values
console.log(values[0] + values[1]);
