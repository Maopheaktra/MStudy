abstract class Operation {
  constructor(
    public number1: number,
    public number2: number) { }

  abstract doOperation(): number;
}

// TODO 1 : Create a class AddOperation, which extends Operation
//          doOpenration must return the sum of the 2 numbers

// TODO 2 : Create a class MultiplyOperation, which extends Operation
//          doOpenration must return the multiplication of the 2 numbers
