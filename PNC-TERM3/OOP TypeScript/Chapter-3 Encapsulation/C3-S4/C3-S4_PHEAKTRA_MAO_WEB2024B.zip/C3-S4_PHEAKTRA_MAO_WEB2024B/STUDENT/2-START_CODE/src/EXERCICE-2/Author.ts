// TODO
export class Author {
    constructor(private name: string) {
        this.name = name;
    }
    getName() {
        return this.name;
    }
}